package apiautomation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class testAssert {

	@Test
	public void testAssertMethod()
	{
		Assert.assertEquals(1, 2);
	}
	
}
