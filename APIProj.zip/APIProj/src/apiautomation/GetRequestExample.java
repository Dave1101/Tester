package apiautomation;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.sound.midi.Synthesizer;

import org.testng.Assert;
import org.testng.annotations.Test;

import groovy.transform.ASTTest;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequestExample {

	@Test
	public void GetDetails() {
		RestAssured.baseURI = "https://reqres.in/api/users";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.get("/4");
		int statusCode = response.getStatusCode();
		System.out.println("status code is :" + statusCode);
		Assert.assertEquals(statusCode, 200);
		String statusLine = response.getStatusLine();
		System.out.println("status body is :" + statusLine);
	
		
		// First get the JsonPath object instance from the Response interface
		JsonPath jsonPathEvaluator = response.jsonPath();
		Map<Object, Object> abc = jsonPathEvaluator.get("data");

		System.out.println(abc);

		Map<Object, Object> map = new LinkedHashMap<Object, Object>();
		map.putAll(abc);

		for (Map.Entry m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		System.out.println(map.get("id"));
	}

	
}
